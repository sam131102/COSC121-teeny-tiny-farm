package P4;

import java.io.Serializable;
import java.util.Iterator;

import MyDoublyLinkedList.Node;

public class AnimalList<Animal, E> implements Iterable<Animal>, Serializable{
	private int size;
	private AnimalNode<Animal> head, tail;
	
	//Constructors
	public AnimalList() {head = tail = null;}
	public AnimalList(Animal[] objects) {
		for (int i = 0; i < objects.length; i++)
			add(i, objects[i]);
	}
	
	//Methods
	
	public int size() { return size;}
	public boolean isEmpty() { return size == 0;}
	
	//Adding
	public void addFirst(Animal animal) {
		AnimalNode<Animal> newNode = new AnimalNode<Animal>(animal);
		if (tail == null)
			head = tail = newNode;
		else {
			newNode.next = head;
			head = newNode;
		}
		size++;
	}
	public void addLast(Animal animal) {
		AnimalNode<Animal> newNode = new AnimalNode<Animal>(animal);
		if (tail == null)
			head = tail = newNode;
		else {
			tail.next = newNode;
			tail = tail.next;
		}
		size++;
	}
	public void add(int index, Animal animal) {
		if (index < 0 || index > size)
			throw new IndexOutOfBoundsException();
		else if (index == 0)	addFirst(animal);
		else if (index == size) addLast(animal);
		else {
			AnimalNode<Animal> newNode = new AnimalNode<Animal>(animal);
			AnimalNode<Animal> current = head;
			for (int i = 1; i < index; i++)
				current = current.next;
			newNode.next = current.next;
			current.next = newNode;
			size++;
	}
	}
	
	//Removing
	public Animal removeFirst() {
		if (size == 0)
			return null;
		else {
			AnimalNode<Animal> temp = head;
			head = head.next;
			size--;
			if (head == null)
				tail = null;
			return temp.element;
		}
	}
	public Animal removeLast() {
		if (size == 0)
			return null;
		else if (size == 1) {
	        AnimalNode<Animal> temp = head;
	        head = tail = null;
	        size = 0;
	        return temp.element;
		} else {
			AnimalNode<Animal> temp = tail;
			AnimalNode<Animal> current = head;
			for (int i = 0; i < size - 2; i++)
				current = current.next;
			tail = current;
			tail.next = null;
			size--;
			return temp.element;
		}
	}
	public Animal remove(int index) {
		if (index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		else if (index == 0)
			return removeFirst();
		else if (index == size - 1)
			return removeLast();
		else {
			AnimalNode<Animal> prev = head;
			for (int i = 1; i < index; i++)
				prev = prev.next;
			AnimalNode<Animal> current = prev.next;
			prev.next = current.next;
			size--;
			return current.element;
	}
	}
	
	//Getting
	public Animal getFirst() {
		if (size == 0)
			return null;
		else
			return head.element;
	}
	public Animal getLast() {
		if (size == 0)
			return null;
		else
			return tail.element;
	}
	public Animal get(int index) {
		if (index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		else if (index == 0)
			return getFirst();
		else if (index == size - 1)
			return getLast();
		else {
			AnimalNode<Animal> current = head;
			for (int i = 0; i < index; i++)
				current = current.next;
			return current.element;
		}
	}
	
	//Setting
	public Animal set(int index, Animal e) {
		if (index < 0 || index > size - 1)
			throw new IndexOutOfBoundsException();
		AnimalNode<Animal> current = head;
		for (int i = 0; i < index; i++)
			current = current.next;
		Animal temp = current.element;
		current.element = e;
		return temp;
	}
	
	//toString
	public String toString() {
		StringBuilder result = new StringBuilder("[");
		AnimalNode<E> current = (AnimalNode<E>) head;
		for (int i = 0; i < size; i++) {
			result.append(current.element);
			current = current.next;
			if (current != null)
				result.append(", ");
			else
				result.append("]");
		}
		return result.toString();
	}
	
	//Custom Methods
	AnimalList getHungryAnimals() {
		for(int i=0; i<size(); i++) {
			if(get(i).getEnergy<50)
				return (AnimalList) get(i);
			else
				return null;
				
		}
	}
	AnimalList getStarvingAnimals() {
		for(int i=0; i<size(); i++) {
			if(get(i).getEnergy<17)
				return (AnimalList) get(i);
			else
				return null;
				
		}
	}
	AnimalList getAnimalsInBarn() {
		
	}
	
	public java.util.Iterator<Animal> iterator() {
		return MyIterator();
	}
	
	
	
}
class AnimalNode<E>{
	E element;
	AnimalNode<E> next;
	public AnimalNode(E e) {
		element = e;
	}
	
}
private class MyIterator() implements java.util.Iterator<Animal>{
	private AnimalNode<E> current = head;
	
	
}